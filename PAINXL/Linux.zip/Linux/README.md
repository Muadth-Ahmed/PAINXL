#

**This is a full course for learning _EML_ with the interpreter for Windows and Linux.**<br>
**Read all of these instructions:** <br>

#

**1. Introduction:**<br><br>
**EML is an Esoteric Programming Language that was created in 2025 by Moaz Ahmed.It was created to be the slowest, hardest language in the world and to be complex with minimal commands.It is very safe.**<br>
**How is EML safe?**<br>
**It creates a virtual environment**<br><br>
**2. Learn:** <br><br>
**To learn EML you will need to know these commands:**

**001001001 (Move the pointer to the right)**

**10101001 (Move the pointer to the left)**

**00100101 (Increase the current cell by 1)**

**10010101 (Decrease the current cell by 1)**

**00000001 (Start a loop)**

**11111101 (End a loop)**

**00101101 (Set current cell to 0)**

**00011101 (Get a character from the user)**

**11100001 (Output an ASCII character)**

**To download the interpreter go to:**
[github.com][https://github.com/Muadth-Ahmed/Esoteric-Machine-Language]
